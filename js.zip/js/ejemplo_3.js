let usuario = "admin";
let password = "12345";

if (usuario == "admin") {

    if (password == "12345") {

        console.log("Bienvenido al sistema");

    } else {

        console.log("Contraseña incorrecta");

    }

} else {

    console.log("Usuario no existe");

}